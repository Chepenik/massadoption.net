# massadoption.net
Mass Adoption Website
This website sparked Conor Chepenik's coding journey. It is built with HTML, CSS and PLAIN OLE JAVASCRIPT.
Lot of people online say you can't do much with plain ole vanilla javascript and in some ways they are right. What they fail to mention is that less is more and sometimes keeping it simple works. I'm always eager to hear tips and feedback but for what MassAdoption currently needs we are happy with this website. In due time we do plan on trying to get some funding so we can go ahead and build out a merchant portal. 

Feel free to fork this code and build out your own meetup page if you are starting a Bitcoin meetup in your area. If you want tips or advice hit Conor's line on Twitter. He's a friendly guy and if you're building a Bitcoin project I'm sure he would be happy to help.